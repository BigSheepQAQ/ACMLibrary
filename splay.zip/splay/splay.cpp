#include<bits/stdc++.h>
#define maxn 50000
using namespace std;
int father[maxn],data[maxn],ls[maxn],rs[maxn],root,tot,ans;
void leftrotate(int x)
{
	int y=father[x];
	rs[y]=ls[x];
	if (ls[x]) father[ls[x]]=y;
	father[x]=father[y];
	if (ls[father[y]]==y) ls[father[y]]=x;
	else if (rs[father[y]]==y) rs[father[y]]=x;
	father[y]=x; ls[x]=y;
}
void rightrotate(int x)
{
	int y=father[x];
	ls[y]=rs[x];
	if (rs[x]) father[rs[x]]=y;
	father[x]=father[y];
	if (ls[father[y]]==y) ls[father[y]]=x;
	else if (rs[father[y]]==y) rs[father[y]]=x;
	father[y]=x; rs[x]=y;
}
void enter(int x)
{
	data[++tot]=x;
	if (root==0) {root=tot; return;}
	int now=root;
	while (true)
	{
		if (x<=data[now])
		{
			if (ls[now]==0) {ls[now]=tot; father[tot]=now; return;}
			now=ls[now];
		}
		else
		{
			if (rs[now]==0) {rs[now]=tot; father[tot]=now; return;}
			now=rs[now];
		}
	}
}
int findpre(int x)
{
	int ans=-1,now=root;
	while (now)
	{
		if (x>=data[now]) {ans=now; now=rs[now];}
		else now=ls[now];
	}
	return ans;
}
int findnxt(int x)
{
	int ans=-1,now=root;
	while (now)
	{
		if (x<=data[now]) {ans=now; now=ls[now];}
		else now=rs[now];
	}
	return ans;
}
void splay(int x, int fa)
{
	if (fa==0) root=x;
	while (father[x]!=fa)
	{
		int y=father[x];
		if (father[y]==fa)
		{
			if (ls[y]==x) rightrotate(x);
			else leftrotate(x);
			return;
		}
		if (ls[y]==x)
		{
			if (ls[father[y]]==y)
			{
				rightrotate(x); rightrotate(x);
			}
			else
			{
				rightrotate(x); leftrotate(x);
			}
		}
		else
		{
			if (ls[father[y]]==y)
			{
				leftrotate(x); rightrotate(x);
			}
			else
			{
				leftrotate(x); leftrotate(x);
			}
		}
	}
}
int main()
{
	int n;
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
	{
		int x,tmp1,tmp2;
		scanf("%d",&x);
		if (i==1) {enter(x); ans+=x; continue;}
		tmp1=findpre(x);
		tmp2=findnxt(x);
		enter(x);
		splay(tot,0);
		if (tmp1==-1) ans+=data[tmp2]-x;
		else if (tmp2==-1) ans+=x-data[tmp1];
		else ans+=min(x-data[tmp1],data[tmp2]-x);
	}
	printf("%d\n",ans);
	return 0;
}
